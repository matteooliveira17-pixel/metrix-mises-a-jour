@echo off
rem ============================================================
rem  Metrix - lanceur Windows
rem  Ouvre le logiciel dans sa propre fenetre (Microsoft Edge ou
rem  Google Chrome en mode application, sans barre d'adresse).
rem ============================================================
setlocal
set "DIR=%~dp0"
set "PAGE=%DIR%app\index.html"

if not exist "%PAGE%" (
  echo.
  echo  Fichier introuvable : %PAGE%
  echo  Decompressez TOUT le fichier zip avant de lancer Metrix.
  echo.
  pause
  exit /b 1
)

set "URL=file:///%PAGE:\=/%"
rem "Convertir Revit" : adresse de l'IFC a ouvrir (index.html#ifc=file:///...)
if not "%~1"=="" set "URL=%URL%#ifc=%~1"

set "EXE="
for %%P in (
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
  "%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
) do if not defined EXE if exist "%%~P" set "EXE=%%~P"

if not defined EXE (
  rem Ni Edge ni Chrome : ouverture dans le navigateur par defaut
  start "" "%PAGE%"
  exit /b 0
)

rem Profil separe : fenetre independante et metres enregistres a part
start "" "%EXE%" --app="%URL%" --user-data-dir="%LocalAppData%\MetrePlan" --allow-file-access-from-files --no-first-run --no-default-browser-check --window-size=1440,900
exit /b 0
