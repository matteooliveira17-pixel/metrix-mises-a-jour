@echo off
rem ============================================================
rem  Metrix - mise a jour 3.25 (version zip)
rem  1. Extrayez tout le zip (clic droit > Extraire tout...).
rem  2. Double-cliquez sur ce fichier : il retrouve votre dossier
rem     Metrix et remplace le logiciel par la nouvelle version.
rem ============================================================
setlocal
title Mise a jour de Metrix 3.25
set "SRC=%~dp0app\index.html"
set "UPD=%~dp0"
if exist "%SRC%" goto go
echo.
echo  Extrayez d'abord tout le zip : clic droit sur le zip, puis
echo  "Extraire tout...", puis double-cliquez sur ce fichier dans
echo  le dossier obtenu.
echo.
pause
exit /b 1

:go
set "FOUND=0"
set "DONE=0"
echo.
echo  Recherche du dossier Metrix...
call :try "%~dp0.."
call :try "%~dp0..\Metrix"
for %%R in ("%USERPROFILE%\Desktop" "%USERPROFILE%\Documents" "%USERPROFILE%\Downloads" "%OneDrive%" "%USERPROFILE%\OneDrive") do call :search "%%~R"

if "%FOUND%"=="0" goto introuvable
echo.
if "%DONE%"=="0" (echo  Metrix etait deja en version 3.25.) else (echo  Metrix est a jour : version 3.25.)
echo  Si Metrix est ouvert, fermez-le puis relancez-le.
echo  Les prochaines mises a jour se feront toutes seules au lancement.
echo  Vos metres, ouvrages et reglages sont conserves.
echo.
pause
exit /b 0

:introuvable
echo.
echo  Dossier Metrix introuvable (le dossier qui contient Metrix.cmd).
echo  Copiez le dossier "app" de cette mise a jour dans votre dossier
echo  Metrix, en remplacant les fichiers existants.
echo.
pause
exit /b 1

rem ---- cherche Metrix.cmd dans un dossier et ses sous-dossiers ----
:search
if "%~1"=="" exit /b
if not exist "%~1\" exit /b
for /f "delims=" %%F in ('dir /s /b /a-d "%~1\Metrix.cmd" 2^>nul') do call :try "%%~dpF"
exit /b

rem ---- met a jour le dossier %1 s'il s'agit bien d'un dossier Metrix ----
:try
set "D=%~f1"
if not "%D:~-1%"=="\" set "D=%D%\"
if not exist "%D%Metrix.cmd" exit /b
if not exist "%D%app\index.html" exit /b
set "FOUND=1"
rem lanceur et conversion Revit : toujours recopies (petits fichiers)
if exist "%UPD%app\convertir-revit.ps1" copy /y "%UPD%app\convertir-revit.ps1" "%D%app\convertir-revit.ps1" >nul 2>&1
if exist "%UPD%app\lancer.ps1" copy /y "%UPD%app\lancer.ps1" "%D%app\lancer.ps1" >nul 2>&1
if exist "%UPD%lanceur\Convertir Revit.cmd" copy /y "%UPD%lanceur\Convertir Revit.cmd" "%D%Convertir Revit.cmd" >nul 2>&1
if exist "%UPD%lanceur\Metrix.cmd" copy /y "%UPD%lanceur\Metrix.cmd" "%D%Metrix.cmd" >nul 2>&1
rem retire la marque "telecharge d'internet" des fichiers de Metrix (Windows ne les bloquera plus)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%D%' -Recurse -File | Unblock-File" >nul 2>&1
fc /b "%SRC%" "%D%app\index.html" >nul 2>&1
if not errorlevel 1 exit /b
copy /y "%D%app\index.html" "%D%app\index-precedent.html" >nul 2>&1
copy /y "%SRC%" "%D%app\index.html" >nul 2>&1
if errorlevel 1 goto tryfail
set "DONE=1"
echo  Mis a jour : %D%
exit /b
:tryfail
echo  Impossible d'ecrire dans : %D%
echo  (fermez Metrix et reessayez)
exit /b
