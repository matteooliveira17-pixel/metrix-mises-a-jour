﻿# Metrix - conversion d'une maquette Revit (.rvt / .rfa) en IFC avec le convertisseur DDC (RVTconverter.exe),
# puis ouverture de l'IFC dans Metrix. Lance par « Convertir Revit.cmd ». Tout se passe sur ce PC.
# Codes de sortie : 0 = IFC ouvert dans Metrix ; 1 = erreur (message affiche) ; 2 = annule par l'utilisateur.
param([string]$Rvt = '')
$ErrorActionPreference = 'Stop'
$app  = Split-Path -Parent $MyInvocation.MyCommand.Path      # ...\Metrix\app
$root = Split-Path -Parent $app                                # ...\Metrix
$ini  = Join-Path $root 'convertisseur-revit.ini'

function Say([string]$t) { Write-Host "  $t" }
function Fail([string]$t) { Write-Host ''; Write-Host "  ERREUR : $t" -ForegroundColor Red; Write-Host ''; exit 1 }

# ---- reglages (convertisseur-revit.ini, a cote de Metrix.cmd) ----
$cfg = [ordered]@{ convertisseur = ''; profil = 'full'; unites = 'm'; origine = 'internal'; delai_minutes = '30'; garder_ifc = 'non' }
if (Test-Path -LiteralPath $ini) {
  foreach ($l in Get-Content -LiteralPath $ini -Encoding UTF8) { if ($l -match '^\s*([a-z_]+)\s*=\s*(.*?)\s*$' -and $cfg.Contains($matches[1])) { $cfg[$matches[1]] = $matches[2] } }
}
function Save-Ini {
  $txt = @(
    '; Reglages de la conversion Revit de Metrix (modifiables avec le Bloc-notes)',
    '; convertisseur : chemin complet de RVTconverter.exe (dossier cli du convertisseur DDC)',
    '; profil : full, coordination ou geometry  -  unites : m ou mm',
    '; origine : internal, project-base-point ou survey-point',
    '; delai_minutes : duree maximale d''une conversion  -  garder_ifc : oui = IFC enregistre a cote du .rvt')
  foreach ($k in $cfg.Keys) { $txt += "$k = $($cfg[$k])" }
  Set-Content -LiteralPath $ini -Value $txt -Encoding UTF8
}

Add-Type -AssemblyName System.Windows.Forms
function Pick([string]$title, [string]$filter) {
  $d = New-Object System.Windows.Forms.OpenFileDialog
  $d.Title = $title; $d.Filter = $filter
  if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $d.FileName }
  return $null
}

Write-Host ''
Write-Host '  Metrix - conversion Revit en IFC' -ForegroundColor Cyan
Write-Host ''

# ---- maquette ----
if (-not $Rvt) { $Rvt = Pick 'Choisir la maquette Revit' 'Maquette Revit (*.rvt;*.rfa)|*.rvt;*.rfa'; if (-not $Rvt) { exit 2 } }
if (-not (Test-Path -LiteralPath $Rvt)) { Fail "fichier introuvable : $Rvt" }
if ($Rvt -notmatch '\.(rvt|rfa)$') { Fail "ce fichier n'est pas une maquette Revit (.rvt ou .rfa)." }

# ---- convertisseur ----
$exe = $cfg.convertisseur
if (-not $exe -or -not (Test-Path -LiteralPath $exe)) {
  $cands = @(
    "$env:SystemDrive\DDC\RVT-to-IFC\cli\RVTconverter.exe",
    "$env:SystemDrive\DDC\RVT-Converter\cli\RVTconverter.exe",
    (Join-Path $root 'DDC\cli\RVTconverter.exe'),
    "$env:LOCALAPPDATA\Programs\DDC RVT to IFC\cli\RVTconverter.exe",
    "$env:LOCALAPPDATA\Programs\DDC RVT Converter\cli\RVTconverter.exe",
    "$env:ProgramFiles\DDC RVT to IFC\cli\RVTconverter.exe",
    "$env:ProgramFiles\DDC RVT Converter\cli\RVTconverter.exe")
  $exe = $cands | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if (-not $exe) {
    Say 'Convertisseur DDC introuvable aux emplacements habituels.'
    Say 'Indiquez ou se trouve RVTconverter.exe (dans le dossier "cli" du convertisseur DDC).'
    $exe = Pick 'Ou se trouve RVTconverter.exe ?' 'Convertisseur DDC (RVTconverter.exe;RVT2IFCconverter.exe)|RVTconverter.exe;RVT2IFCconverter.exe|Programmes (*.exe)|*.exe'
    if (-not $exe) { Fail 'convertisseur DDC introuvable. Telechargez-le sur la page officielle de DDC (voir LISEZMOI), puis relancez.' }
  }
  $cfg.convertisseur = $exe
}
if (-not (Test-Path -LiteralPath $ini) -or $cfg.convertisseur) { Save-Ini }
$legacy = (Split-Path -Leaf $exe) -match '^(RVT2IFCconverter|RvtExporter)\.exe$'

# ---- dossier de travail ----
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$base  = Join-Path $env:TEMP 'Metrix-Revit'
$work  = Join-Path $base $stamp
$out   = Join-Path $work 'ifc'
New-Item -ItemType Directory -Force -Path $work | Out-Null
# anciens fichiers de conversion (plus d'un jour) : effaces
Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-1) } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
$log  = Join-Path $work 'conversion.log'
$elog = Join-Path $work 'erreurs.log'

# ---- ligne de commande (chaque chemin entre guillemets : espaces et accents acceptes) ----
if ($legacy) {
  New-Item -ItemType Directory -Force -Path $out | Out-Null
  $argStr = '"' + $Rvt + '" "' + (Join-Path $out 'maquette.ifc') + '" preset=standard "config=ExportBaseQuantities=true"'
} else {
  $argStr = '"' + $Rvt + '" -o "' + $out + '" --ifc --ifc-profile ' + $cfg.profil + ' --ifc-units ' + $cfg.unites + ' --ifc-origin ' + $cfg.origine
}
Say ('Maquette : ' + (Split-Path -Leaf $Rvt))
Say ('Convertisseur : ' + $exe)
Write-Host ''

$p = Start-Process -FilePath $exe -ArgumentList $argStr -NoNewWindow -PassThru -RedirectStandardOutput $log -RedirectStandardError $elog
$null = $p.Handle   # garde le code de retour disponible
$limit = [math]::Max(1, [int]$cfg.delai_minutes) * 60
$sw = [Diagnostics.Stopwatch]::StartNew()
while (-not $p.WaitForExit(1000)) {
  $s = [int]$sw.Elapsed.TotalSeconds
  Write-Host -NoNewline ("`r  Conversion en cours... {0} min {1:00} s   " -f [int][math]::Floor($s / 60), ($s % 60))
  if ($s -gt $limit) {
    & taskkill.exe /T /F /PID $p.Id | Out-Null
    Fail ("la conversion a depasse $($cfg.delai_minutes) minutes et a ete arretee. Augmentez delai_minutes dans convertisseur-revit.ini.")
  }
}
Write-Host ''
$code = $p.ExitCode
$text = ''
foreach ($f in @($log, $elog)) { if (Test-Path -LiteralPath $f) { $text += (Get-Content -LiteralPath $f -Raw -ErrorAction SilentlyContinue) } }

# journal gardé (10 derniers) : %LOCALAPPDATA%\Metrix\journaux-revit
$logs = Join-Path $env:LOCALAPPDATA 'Metrix\journaux-revit'
New-Item -ItemType Directory -Force -Path $logs | Out-Null
$kept = Join-Path $logs "conversion-$stamp.log"
Set-Content -LiteralPath $kept -Value ("RVTconverter " + $argStr + "`r`ncode : $code`r`n`r`n" + $text) -Encoding UTF8
Get-ChildItem -LiteralPath $logs -Filter 'conversion-*.log' | Sort-Object Name -Descending | Select-Object -Skip 10 | Remove-Item -Force -ErrorAction SilentlyContinue

# ---- resultat ----
$ifc = $null
if (Test-Path -LiteralPath $out) { $ifc = Get-ChildItem -LiteralPath $out -Recurse -Filter '*.ifc' | Where-Object { $_.Length -gt 0 } | Sort-Object Length -Descending | Select-Object -First 1 }
if (-not $ifc -or ($code -ne 0 -and $code -ne 2)) {
  if ($text -match '(?i)(unsupported|not supported).{0,40}(version|revit)|older than 2019') { Fail 'version de Revit non prise en charge (fichiers Revit 2019 a 2027). Ouvrez et enregistrez la maquette dans une version plus recente de Revit.' }
  if ($text -match '(?i)corrupt|not a valid|invalid (rvt|file|ole|compound)|cannot (read|open|parse)|failed to (open|read|parse)') { Fail "fichier Revit illisible ou endommage. Journal : $kept" }
  if ($code -eq 0 -or $code -eq 2) { Fail "la conversion s'est terminee sans produire de fichier IFC. Journal : $kept" }
  Fail "la conversion a echoue (code $code). Journal : $kept"
}
if ($code -eq 2) { Say 'Maquette convertie avec des remarques : certains elements peuvent manquer (voir le journal).' }

# ---- IFC : a cote du .rvt (garder_ifc = oui) ou dans le dossier temporaire ----
$stem = [IO.Path]::GetFileNameWithoutExtension($Rvt)
if ($cfg.garder_ifc -match '^(oui|yes|1|true)$') {
  $dir = Split-Path -Parent $Rvt; $dest = Join-Path $dir "$stem.ifc"; $n = 2
  while (Test-Path -LiteralPath $dest) { $dest = Join-Path $dir "$stem ($n).ifc"; $n++ }
} else { $dest = Join-Path $base "$stem.ifc" }
Copy-Item -LiteralPath $ifc.FullName -Destination $dest -Force
Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
Say ('IFC : ' + $dest)

# ---- ouverture dans Metrix ----
$url = ([Uri]$dest).AbsoluteUri
& (Join-Path $root 'Metrix.cmd') $url
exit 0
