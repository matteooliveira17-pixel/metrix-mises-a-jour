@echo off
rem ============================================================
rem  Metrix - convertit une maquette Revit (.rvt) en IFC avec le
rem  convertisseur DDC installe sur ce PC, puis l'ouvre dans Metrix.
rem  Glissez le fichier .rvt sur ce fichier, ou double-cliquez
rem  dessus pour choisir la maquette.
rem  Reglages : convertisseur-revit.ini (cree au premier lancement).
rem ============================================================
setlocal
title Metrix - conversion Revit
if not exist "%~dp0app\convertir-revit.ps1" (
  echo.
  echo  Fichier introuvable : app\convertir-revit.ps1
  echo  Decompressez TOUT le zip de Metrix, puis relancez.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\convertir-revit.ps1" "%~1"
if errorlevel 1 pause
exit /b 0
